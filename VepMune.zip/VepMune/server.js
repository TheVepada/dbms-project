const express = require('express');
const pool = require('./db_connect');

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get('/test', (req, res) => {
  res.send('Backend is working!');
});

app.post('/addUser', async (req, res) => {
  const { name, email, subscription } = req.body;
  try {
    await pool.execute(
      'INSERT INTO `User` (Name, Email, SubscriptionType, JoinDate) VALUES (?, ?, ?, CURDATE())',
      [name, email, subscription]
    );
    res.json({ status: 'success' });
  } catch (err) {
    res.json({ status: 'error', message: err.message });
  }
});

app.post('/addSong', async (req, res) => {
  const { albumID = 1, title = 'New Track', duration = 200, genre = 'Pop' } = req.body;
  try {
    await pool.execute(
      'INSERT INTO Song (AlbumID, Title, Duration, Genre) VALUES (?, ?, ?, ?)',
      [albumID, title, duration, genre]
    );
    res.send('Song added successfully!');
  } catch (err) {
    res.status(500).send('Error: ' + err.message);
  }
});

app.post('/addPayment', async (req, res) => {
  const { userID, amount, method } = req.body;
  try {
    await pool.execute(
      'INSERT INTO Payment (UserID, Amount, Date, Method) VALUES (?, ?, CURDATE(), ?)',
      [userID, amount, method]
    );
    res.json({ status: 'success' });
  } catch (err) {
    res.json({ status: 'error', message: err.message });
  }
});

app.get('/getSongs', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT SongID, Title, Genre, Duration FROM Song');
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/getPayments', async (req, res) => {
  const userID = req.query.userID;
  try {
    const [rows] = await pool.execute('SELECT PaymentID, Amount, Date, Method FROM Payment WHERE UserID = ?', [userID]);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/getPlaylists', async (req, res) => {
  const userID = req.query.userID || 1;
  try {
    const [rows] = await pool.execute('SELECT Name FROM Playlist WHERE UserID = ?', [userID]);
    if (rows.length === 0) return res.send('No playlists found.');
    res.json(rows.map(r => ({ playlist: r.Name })));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/getStreams', async (req, res) => {
  const userID = req.query.userID;
  try {
    const [rows] = await pool.execute(
      `SELECT s.Title, l.Timestamp, l.Device
       FROM StreamingLog l
       JOIN Song s ON l.SongID = s.SongID
       WHERE l.UserID = ?`,
      [userID]
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/getUsers', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT UserID, Name, Email, SubscriptionType FROM User');
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/logStream', async (req, res) => {
  const { userID, songID, device } = req.body;
  try {
    await pool.execute('INSERT INTO StreamingLog (UserID, SongID, Timestamp, Device) VALUES (?, ?, NOW(), ?)', [userID, songID, device]);
    res.json({ status: 'logged' });
  } catch (err) {
    res.json({ status: 'error', message: err.message });
  }
});

app.post('/manageSubscription', async (req, res) => {
  const { userID, type, status } = req.body;
  try {
    await pool.execute(
      'INSERT INTO Subscription (UserID, Type, StartDate, EndDate, PaymentStatus) VALUES (?, ?, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 30 DAY), ?)',
      [userID, type, status]
    );
    res.json({ status: 'success' });
  } catch (err) {
    res.json({ status: 'error', message: err.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server listening on port ${PORT}`));
