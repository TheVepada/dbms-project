<?php
include 'db_connect.php';

$name = $_POST['name'];
$email = $_POST['email'];
$type = $_POST['subscription'];

$sql = "INSERT INTO User (Name, Email, SubscriptionType, JoinDate)
        VALUES ('$name', '$email', '$type', CURDATE())";

if ($conn->query($sql) === TRUE) {
  echo json_encode(["status"=>"success"]);
} else {
  echo json_encode(["status"=>"error","message"=>$conn->error]);
}

$conn->close();
?>
