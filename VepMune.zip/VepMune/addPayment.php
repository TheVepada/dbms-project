<?php
include 'db_connect.php';

$userID = $_POST['userID'];
$amount = $_POST['amount'];
$method = $_POST['method'];

$sql = "INSERT INTO Payment (UserID, Amount, Date, Method)
        VALUES ($userID, $amount, CURDATE(), '$method')";

if ($conn->query($sql) === TRUE) {
  echo json_encode(["status"=>"success"]);
} else {
  echo json_encode(["status"=>"error","message"=>$conn->error]);
}

$conn->close();
?>
