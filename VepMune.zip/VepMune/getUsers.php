<?php
include 'db_connect.php';

$sql = "SELECT UserID, Name, Email, SubscriptionType FROM User";
$result = $conn->query($sql);

$users = [];
while($row = $result->fetch_assoc()) {
  $users[] = $row;
}

echo json_encode($users);
$conn->close();
?>
