conn.query("SELECT * FROM songs", (err, results) => {
  if (err) throw err;
  console.log(results);
});
