<?php
include 'db_connect.php';

$userID = 1; // Example: logged-in user

$sql = "SELECT Name FROM Playlist WHERE UserID = $userID";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    echo "Playlist: " . $row["Name"] . "<br>";
  }
} else {
  echo "No playlists found.";
}

$conn->close();
?>
