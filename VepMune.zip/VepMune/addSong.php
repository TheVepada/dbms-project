<?php
include 'db_connect.php';

$albumID = 1;
$title = "New Track";
$duration = 200;
$genre = "Pop";

$sql = "INSERT INTO Song (AlbumID, Title, Duration, Genre)
        VALUES ($albumID, '$title', $duration, '$genre')";

if ($conn->query($sql) === TRUE) {
  echo "Song added successfully!";
} else {
  echo "Error: " . $conn->error;
}

$conn->close();
?>
