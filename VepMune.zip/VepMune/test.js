const pool = require("./db_connect");

pool.query("SHOW TABLES;", (err, results) => {
  if (err) {
    console.error(err);
  } else {
    console.log("Tables:", results);
  }
});
