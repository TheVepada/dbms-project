<?php
include 'db_connect.php';

$sql = "SELECT SongID, Title, Genre, Duration FROM Song";
$result = $conn->query($sql);

$songs = [];
while($row = $result->fetch_assoc()) {
  $songs[] = $row;
}

echo json_encode($songs);
$conn->close();
?>
