<?php
include 'db_connect.php';

$userID = $_POST['userID'];
$songID = $_POST['songID'];
$device = $_POST['device'];

$sql = "INSERT INTO StreamingLog (UserID, SongID, Timestamp, Device)
        VALUES ($userID, $songID, NOW(), '$device')";

if ($conn->query($sql) === TRUE) {
  echo json_encode(["status"=>"logged"]);
} else {
  echo json_encode(["status"=>"error","message"=>$conn->error]);
}

$conn->close();
?>
