<?php
include 'db_connect.php';

$userID = $_GET['userID'];

$sql = "SELECT PaymentID, Amount, Date, Method FROM Payment WHERE UserID = $userID";
$result = $conn->query($sql);

$payments = [];
while($row = $result->fetch_assoc()) {
  $payments[] = $row;
}

echo json_encode($payments);
$conn->close();
?>
