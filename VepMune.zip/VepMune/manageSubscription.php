<?php
include 'db_connect.php';

$userID = $_POST['userID'];
$type = $_POST['type'];
$status = $_POST['status'];

$sql = "INSERT INTO Subscription (UserID, Type, StartDate, EndDate, PaymentStatus)
        VALUES ($userID, '$type', CURDATE(), DATE_ADD(CURDATE(), INTERVAL 30 DAY), '$status')";

if ($conn->query($sql) === TRUE) {
  echo json_encode(["status"=>"success"]);
} else {
  echo json_encode(["status"=>"error","message"=>$conn->error]);
}

$conn->close();
?>
