const mysql = require("mysql2");

const conn = mysql.createConnection({
  host: "127.0.0.1",   // use IPv4 instead of localhost (::1)
  user: "root",        // default XAMPP user
  password: "",        // empty unless you set one
  database: "vepmune",
  port: 3306           // default port, change if XAMPP uses 3307
});

conn.connect(err => {
  if (err) {
    console.error("Connection failed:", err);
    return;
  }
  console.log("Local MySQL/MariaDB connected!");
});
