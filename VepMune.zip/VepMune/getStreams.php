<?php
include 'db_connect.php';

$userID = $_GET['userID'];

$sql = "SELECT s.Title, l.Timestamp, l.Device
        FROM StreamingLog l
        JOIN Song s ON l.SongID = s.SongID
        WHERE l.UserID = $userID";
$result = $conn->query($sql);

$logs = [];
while($row = $result->fetch_assoc()) {
  $logs[] = $row;
}

echo json_encode($logs);
$conn->close();
?>
