<?php
$host = "vepmune-db.mysql.database.azure.com";
$user = "vepmune_admin@vepmune-db";
$password = "RamMun++";
$dbname = "vepmune";

// SSL certificate (download from Azure portal)
$sslcert = "DigiCertGlobalRootG2.crt.pem";

$conn = mysqli_init();
mysqli_ssl_set($conn, NULL, NULL, $sslcert, NULL, NULL);
mysqli_real_connect($conn, $host, $user, $password, $dbname, 3306, NULL, MYSQLI_CLIENT_SSL_DONT_VERIFY_SERVER_CERT);

if (mysqli_connect_errno()) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully!";
?>
